# Pixelator Internal Documentation

## Overview
Pixelator is a canvas-based image pixelation and color quantization tool with an interactive layer system. It allows users to:

- Load an image and automatically fit it within a flexible container.
- Pixelate the image to a specified tile size.
- Quantize colors to a limited palette using k-means clustering.
- Draw, erase, recolor, and mirror pixels.
- Manage multiple layers for non-destructive editing.
- Toggle a grid overlay for precise pixel-level editing.

It is designed as a standalone app with future scalability for a full layer stack.

---

## Core Components

### Layer Class
Represents a single layer in the canvas.

- Stores:
  - `width` and `height` of the layer.
  - `imageData` (RGBA pixels).
  - `colors` — a list of color objects: `{ r, g, b, pixels, erased }`.
- Acts as a container for pixel-level editing and allows stacking multiple layers in the future.

### CanvasManager Class
Handles all operations on the canvas and layers:

1. **Image Loading & Resizing**
   - Loads an image into the canvas and scales it to fit a flexible container.
   - Maintains aspect ratio for portrait and landscape images.
   - Creates a base layer (`Layer`) with the loaded image’s pixel data.

2. **Pixelation & Color Quantization**
   - `applyQuantizeAndTile(img, colorCount, tileSize)`:
     - Downscale image to grid.
     - Quantize colors using K-means.
     - Upscale tiles back to full canvas.
     - Store in a new `Layer`.

3. **Grid Drawing**
   - Overlays grid lines aligned to tile size.

4. **Pixel Editing**
   - `erasePixels(pixels)` → makes pixels transparent.
   - `recolorPixels(pixels, r, g, b)` → replaces pixel color.
   - `drawBoundingBox(pixels)` → highlight region.

5. **Layer Management**
   - Currently supports one active layer.
   - Designed for a stack of layers in the future.

---

## Data Flow

[ Image File ] → loadImage()  
→ Base Layer (ImageData)  
→ Pixelation (downscale → quantize → upscale)  
→ New Quantized Layer  
→ Redraw Canvas  
→ Interactive Editing  

---

## Key Techniques
- **Pixel-perfect Scaling** (no smoothing).
- **Tile-based Processing** for efficient quantization.
- **K-means Quantization** in RGB space.
- **Direct ImageData Manipulation** for fast updates.

---

## Future Improvements
- Layer stack with blending modes.
- Mirror drawing modes.
- Undo/redo stack.
- Optimized palette indexing.
